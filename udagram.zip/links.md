# Frontend link fro s3
- http://ud-bucket.s3-website-us-east-1.amazonaws.com/home
# api link from EB
-http://udagram-api-dev.eba-bmi9miik.us-west-2.elasticbeanstalk.com/
# database end point and port from rds
- Endpoint
ud.cwuvn5rx4kzp.us-east-1.rds.amazonaws.com
- Port
5432