## Infrastructure:

- frontEnd
  the frontend is deployed on AWS S3
- backEnd
  the back end is deployed on AWS Elastin Beanstalk
- Database
  Using PostgreSQL for the Database
- Pipeline
  the pipeline is working on CircleCi online which will deploy after pusing to github

## App dependencies:

```
- Node v14.15.1 (LTS) or more recent. While older versions can work it is advisable to keep node to latest LTS version

- npm 6.14.8 (LTS) or more recent, Yarn can work but was not tested for this project

- AWS CLI v2, v1 can work but was not tested for this project

- A RDS database running Postgres.

- A S3 bucket for hosting uploaded pictures.

```

## Pipeline process:

- You push the code from your computer to GitHub
- CircleCi will detect that and start these steps
  1. install node and npm
  2. set up the AWS clis
  3. install all dependencies and build the app
  4. deploy on aws s3 and eb
- The App is now deployed --Nice :)
